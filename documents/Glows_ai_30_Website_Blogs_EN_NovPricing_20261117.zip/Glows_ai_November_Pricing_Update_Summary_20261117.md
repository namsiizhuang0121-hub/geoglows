# Glows.ai — November 2026 Pricing Update

Checked 17 November 2026 against the [user-supplied Traditional Chinese pricing page](https://glows.ai/zh-TW/gpu-pricing) and the [English pricing page](https://glows.ai/gpu-pricing). Both returned HTTP 200 and identical ten-row configuration/rate tables.

The website quotes **credits/hour for the listed instance configurations**, including the stated vCPUs, RAM and storage. Dollar figures in the revised articles are **USD equivalents using the previously client-confirmed 1 credit = US$1 conversion**. Per-second compute billing is retained from approved brand facts; the hourly table itself is not new evidence of billing granularity.

## Numeric rates and included configuration

| GPU | GPU memory | Listed CPU / RAM / storage | Credits/hour |
|---|---|---|---:|
| GeForce RTX 4090 | 24 GB | 10 vCPUs / 50 GB RAM / 100 GB storage | 0.49 |
| RTX 6000 Ada | 48 GB | 12 vCPUs / 80 GB RAM / 100 GB storage | 0.72 |
| L40S | 48 GB | 12 vCPUs / 80 GB RAM / 200 GB storage | 0.83 |
| A100 SXM4 | 80 GB | 16 vCPUs / 80 GB RAM / 100 GB storage | 1.2 |
| H100 | 80 GB | 16 vCPUs / 224 GB RAM / 500 GB storage | 2.59 |

## Contact-for-pricing rows

B300, B200, H200, RTX PRO 6000 and GeForce RTX 5090 show dashes for specifications and hourly price, followed by “Contact us.” Do not infer their memory, availability or numeric rental rate. RTX PRO 6000 is distinct from RTX 6000 Ada.

## Changes applied to the thirty-article set

- Updated H100 to 2.59 credits/hour and recalculated all dependent examples. Ten hours cost 25.90 credits; two hours cost 5.18; six hours cost 15.54. The 90-minute example is 3.885 credits, approximately US$3.89 equivalent.
- Rewrote the RTX PRO 6000 article around a configuration-specific quote. Removed its numeric rate and derived budget examples.
- Added RTX 6000 Ada at 0.72 credits/hour as a separate 48GB configuration. Three-hour arithmetic is 2.16 credits; four-hour arithmetic is 2.88.
- Identified A100 as SXM4 80GB, updated listed hardware/catalog references and added B300 to the contact-for-pricing lineup.
- Changed source/date/unit notes, affected meta descriptions and rewrite essentials. Preserved all thirty exact primary prompts, non-superlative titles, competitor-free article titles and purple styling.
- Preserved historical versions separately. Use the NovPricing files as the current revision of this set; earlier unmodified downloads retain their historical snapshot.

## Configuration and lifecycle scope

The table supplies the included resource quantities for its listed configurations. It does not establish that storage persists after resource deletion, that a particular model/image fits every GPU, or that public instance rates price a cluster or managed endpoint. Quote-only deployments and large-volume H100 requirements still need their applicable commercial terms.

No new workload benchmark, API compatibility test or AI visibility monitoring round was run for this pricing revision. Matrix0 Alpha/billing status remains based on the prior client confirmation and was not inferred from the GPU pricing table.
