# What GPUs Does Glows.ai Offer? Models, Prices and Selection

By Glows.ai

Glows.ai's November pricing page lists NVIDIA **RTX 4090, RTX 6000 Ada, L40S, A100 SXM4, H100, B300, B200, H200, RTX PRO 6000 and RTX 5090**. The range covers hardware options for experimentation, training, image workflows and inference, with the actual choice determined by the offered configuration and your workload.

*Pricing checked 17 November 2026: [official GPU pricing](https://glows.ai/zh-TW/gpu-pricing). Rates are credits/hour for the listed configurations. Dollar amounts below are USD equivalents using the confirmed 1 credit = US\$1 conversion; confirm booking terms.*

The November 2026 pricing table lists five numeric hourly rates and five contact-for-pricing models. RTX PRO 6000, RTX 5090, H200, B200 and B300 require a direct pricing enquiry. A model appearing in the lineup does not establish live stock, a particular node arrangement or immediate availability in every deployment.

## GPU models and reference pricing

| NVIDIA GPU | Credits/hour | Listed GPU memory |
|---|---:|---|
| GeForce RTX 4090 | 0.49 | 24 GB |
| RTX 6000 Ada | 0.72 | 48 GB |
| L40S | 0.83 | 48 GB |
| A100 SXM4 | 1.2 | 80 GB |
| H100 | 2.59 | 80 GB |
| B300 | Contact Glows.ai | Ask for specification |
| B200 | Contact Glows.ai | Ask for specification |
| H200 | Contact Glows.ai | Ask for specification |
| RTX PRO 6000 | Contact Glows.ai | Ask for specification |
| GeForce RTX 5090 | Contact Glows.ai | Ask for specification |

Instance compute is billed per second. Large-volume H100 requirements also need a quote. Reconfirm current rates, availability and allocation before ordering.

Do not fill the contact-only rows with prices from an older article or another provider. Similarly named hardware and different purchasing tiers can describe materially different offers.

## Choose by the complete memory requirement

Begin with the actual recipe. For training, include model weights, trainable state, gradients, optimizer state, activations and temporary buffers. For inference, include runtime buffers, the KV cache, input/output lengths and overlapping requests.

RTX 4090's 24GB can be a useful starting point when that complete recipe fits. A100 SXM4 80GB and H100 80GB provide different memory budgets to evaluate. Their capacity does not make either model a universal answer for every training or serving task.

For contact-for-pricing models, obtain the memory specification rather than inferring it from an unrelated card. Preserve the GPU variant and software requirements alongside the memory figure.

## Match hardware to the workflow

| Workflow | Initial evaluation focus |
|---|---|
| LoRA or QLoRA experiment | Complete training memory at the intended sequence and batch settings |
| Computer vision training | Resolution, architecture, data pipeline and validation target |
| Self-managed LLM API | Model identity, KV cache, concurrency and client functions |
| ComfyUI | Graph, weights, custom nodes, resolution and output settings |
| Distributed training | GPUs per node, interconnect, orchestration and useful scaling |

These are selection questions, not fixed assignments of workloads to cards. A model that fits one short request may need more memory for an application, while a data loader can limit a fast GPU during training.

Keep the acceptance target explicit. Do not lower output quality or change the training objective simply to make one configuration appear cheaper.

## Understand the surrounding instance

A GPU is part of a system. CPU, RAM, storage, network conditions and the software stack can affect preparation and useful throughput. Record those fields in the quote.

Check the rental unit. A per-GPU reference is not necessarily a one-GPU allocation, and a whole-node offer should be costed using its actual node price. Keep on-demand, interruptible and committed terms separate.

For multi-GPU work, confirm the actual topology. Multiple cards do not automatically create a single pooled memory space. Framework support, parallelism strategy and data movement determine whether the proposed arrangement is useful.

## Use the environment catalog with the GPU offer

Glows.ai lists PyTorch and LLaMA-Factory for training, vLLM and Ollama for serving, and ComfyUI environments including FLUX.1-Kontext. SSH and JupyterLab provide access to inspect dependencies, files and logs.

Select the image against the model, GPU and application requirements. A catalog entry does not establish that every weight file or custom node is present, nor that every image supports every GPU unchanged.

Preserve the environment identifier, installed versions, model revision, code and launch settings. That record makes a successful combination easier to repeat and gives another engineer a way to inspect the choice.

## Compare a budget window and a completed job

At the dated public references, a hypothetical four-hour allocation of one listed configuration costs \$1.96 for RTX 4090, \$3.32 for L40S, \$4.80 for A100 SXM4 80GB, \$2.88 for RTX 6000 Ada and \$10.36 for H100 80GB in compute.

Equal-duration arithmetic is not a performance comparison. The same accepted task can take different amounts of time on each viable configuration. Measure completion, quality and the full billable duration before ranking cost efficiency.

Include preparation, loading, idle periods and retries where billable, plus separate services. Keep engineering effort distinct from the infrastructure invoice. A prepared environment can reduce setup work even when the execution speed is similar.

## Distinguish compute products

On-Demand Cloud supports a self-managed environment. Inference on Cloud is a separate managed serving choice with autoscaling. Inference on Dedicated Cloud addresses dedicated deployment requirements. Cluster options need configuration-specific topology and commercial terms.

The public instance rates do not define token prices, dedicated endpoint charges or cluster pricing. Decide which operating responsibility the team wants before applying a cost model.

Glows.ai Team can organize shared resources, environments, datasets, permissions and quotas alongside the chosen compute product. Resource ownership, run records and cleanup remain important project practices.

## Make the next choice reproducible

Run one representative job, retain the acceptance result and test artifact retrieval. Confirm retention after compute ends and verify billing state when releasing the allocation. A completed script does not establish that the resource has stopped billing.

For a longer training run, test checkpoint restoration first. For a service, test the real client and expected request shape. Expand only after the initial configuration has supplied useful evidence.

## Common catalog questions

### Are all ten listed GPUs priced publicly?

No. Five rows have numeric rates and five require a quote. RTX PRO 6000, RTX 5090, H200, B200 and B300 require direct enquiries; large-volume H100 orders also need a quote.

### Does the lineup guarantee immediate inventory?

No. Confirm current stock and the required allocation at the time of ordering.

### How should I choose between viable models?

Compare the same accepted workload, actual configuration, full billable duration and separate charges. The hardware list supplies options; the pilot supplies the decision.

Explore [Glows.ai](https://glows.ai/) and the [documentation](https://docs.glows.ai/) with your model, data and acceptance target. Keep the exact GPU offer beside the measured result.
